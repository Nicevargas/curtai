import { supabase } from '../lib/supabase';
import { GeneratedContent } from '../types';

export const getUserContent = async (userId: string): Promise<GeneratedContent[]> => {
  const { data, error } = await supabase
    .from('conteudos_gerados')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    throw error;
  }

  return data.map((item: any) => ({
    id: item.id,
    type: item.tipo || item.type, // Mantém compatibilidade para tipo
    url: item.link_arquivo || item.url, // Mantém compatibilidade para link
    prompt: item.prompt, // Lê ESTRITAMENTE a coluna 'prompt' conforme solicitado
    created_at: new Date(item.created_at).toLocaleDateString('pt-BR')
  }));
};

export const getRecentMedia = async (userId: string, limit: number = 3): Promise<GeneratedContent[]> => {
  const { data, error } = await supabase
    .from('conteudos_gerados')
    .select('*')
    .eq('user_id', userId)
    // Removed type filter to allow videos and images
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    console.error("Erro ao buscar mídia recente:", error);
    return [];
  }

  return data.map((item: any) => ({
    id: item.id,
    type: item.tipo || item.type,
    url: item.link_arquivo || item.url,
    prompt: item.prompt,
    created_at: new Date(item.created_at).toLocaleDateString('pt-BR')
  }));
};

export const deleteContent = async (id: string, url?: string) => {
  // 1. Tenta excluir o arquivo físico do Storage se for um arquivo do Supabase
  if (url && url.includes('/storage/v1/object/public/')) {
    try {
      // Extrai o caminho do arquivo da URL: .../public/BUCKET/PASTA/ARQUIVO
      const pathPart = url.split('/storage/v1/object/public/')[1];
      if (pathPart) {
        const [bucketName, ...filePathParts] = pathPart.split('/');
        const filePath = filePathParts.join('/');
        
        if (bucketName && filePath) {
          console.log(`Tentando excluir arquivo físico: Bucket=${bucketName}, Path=${filePath}`);
          const { error: storageError } = await supabase.storage
            .from(bucketName)
            .remove([filePath]);
            
          if (storageError) {
            console.warn("Aviso: Não foi possível excluir o arquivo físico do Storage (pode ser falta de permissão ou arquivo já inexistente).", storageError);
          }
        }
      }
    } catch (err) {
      console.warn("Erro ao tentar processar exclusão de arquivo físico:", err);
    }
  }

  // 2. Exclui o registro do Banco de Dados
  const { error } = await supabase
    .from('conteudos_gerados')
    .delete()
    .eq('id', id);

  if (error) throw error;
};