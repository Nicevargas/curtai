import React, { useState, useEffect } from 'react';
import { Image as ImageIcon, Video, Filter, Loader2, Download, Trash2, Database, Terminal, PlayCircle } from 'lucide-react';
import { User, GeneratedContent } from '../types';
import { getUserContent, deleteContent } from '../services/contentService';
import { useLocation } from 'react-router-dom';

interface GalleryPageProps {
  user: User;
}

const GalleryPage: React.FC<GalleryPageProps> = ({ user }) => {
  const [items, setItems] = useState<GeneratedContent[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'image' | 'video'>('all');
  const [showSqlModal, setShowSqlModal] = useState(false);
  
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('setup') === 'true') {
      setShowSqlModal(true);
    }
  }, [location]);

  const fetchContent = async () => {
    setLoading(true);
    try {
      const data = await getUserContent(user.id);
      setItems(data);
    } catch (error: any) {
      console.error("Erro ao carregar galeria:", error);
      // Se a tabela não existir, sugere configuração
      if (error.message?.includes('relation "conteudos_gerados" does not exist') || error.code === '42P01') {
        setShowSqlModal(true);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchContent();
    }
  }, [user]);

  const handleDelete = async (id: string, url: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Tem certeza que deseja excluir este arquivo permanentemente?')) {
      try {
        // Passamos a URL para tentar apagar o arquivo físico também
        await deleteContent(id, url);
        setItems(prev => prev.filter(item => item.id !== id));
      } catch (error: any) {
        console.error("Erro na exclusão:", error);
        if (error.code === '42501') {
           setShowSqlModal(true); // Erro de permissão
        } else {
           alert(`Erro ao excluir item: ${error.message}`);
        }
      }
    }
  };
  
  const handleDownload = async (url: string, filename: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename || 'download';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error("Erro no download:", error);
      // Fallback para abrir em nova aba se o fetch falhar (CORS)
      window.open(url, '_blank');
    }
  };

  const filteredItems = items.filter(item => filter === 'all' || item.type === filter);

  // Script SQL atualizado com permissões de STORAGE
  const sqlScript = `-- 1. Cria a tabela de conteúdos gerados
create table if not exists public.conteudos_gerados (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users not null,
  tipo text not null, 
  link_arquivo text not null,
  prompt text,
  created_at timestamp with time zone default now()
);

-- 2. Habilita segurança na TABELA
alter table public.conteudos_gerados enable row level security;

-- 3. Remove políticas antigas da TABELA
drop policy if exists "Gerenciar meus conteudos" on public.conteudos_gerados;
drop policy if exists "Usuários veem seus conteudos" on public.conteudos_gerados;
drop policy if exists "Qualquer um insere conteudos" on public.conteudos_gerados;
drop policy if exists "Usuários deletam seus conteudos" on public.conteudos_gerados;

-- 4. Cria políticas de acesso da TABELA
create policy "Gerenciar meus conteudos"
on public.conteudos_gerados for all
to authenticated
using ( auth.uid()::text = user_id::text )
with check ( auth.uid()::text = user_id::text );

-- 5. PERMISSÕES DE STORAGE (Opcional, mas recomendado se usar buckets)
-- Isso permite que usuários autenticados façam tudo em qualquer bucket público
create policy "Authenticated users full access to buckets"
on storage.objects for all
to authenticated
using ( true )
with check ( true );
`;

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <ImageIcon className="text-sky-500" /> Galeria de Criações
          </h1>
          <p className="text-slate-500 text-sm">Visualize todas as imagens e vídeos que você gerou</p>
        </div>

        <div className="flex items-center gap-2 bg-white p-1 rounded-lg border border-slate-200">
           <button 
             onClick={() => setFilter('all')}
             className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${filter === 'all' ? 'bg-sky-100 text-sky-700' : 'text-slate-500 hover:bg-slate-50'}`}
           >
             Todos
           </button>
           <button 
             onClick={() => setFilter('image')}
             className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-1 ${filter === 'image' ? 'bg-sky-100 text-sky-700' : 'text-slate-500 hover:bg-slate-50'}`}
           >
             <ImageIcon size={14} /> Imagens
           </button>
           <button 
             onClick={() => setFilter('video')}
             className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-1 ${filter === 'video' ? 'bg-sky-100 text-sky-700' : 'text-slate-500 hover:bg-slate-50'}`}
           >
             <Video size={14} /> Vídeos
           </button>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center h-64">
          <Loader2 className="w-8 h-8 text-sky-500 animate-spin mb-2" />
          <p className="text-slate-400">Carregando galeria...</p>
        </div>
      ) : filteredItems.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4">
          {filteredItems.map((item) => (
            <div key={item.id} className="bg-white rounded-lg overflow-hidden border border-slate-100 shadow-sm hover:shadow-md transition-all group relative flex flex-col">
               
               {/* Media Display */}
               <div className="aspect-square bg-slate-100 relative overflow-hidden">
                  {item.type === 'video' ? (
                    <div className="w-full h-full flex items-center justify-center bg-slate-900 group-hover:scale-105 transition-transform duration-500">
                       <video src={item.url} className="w-full h-full object-cover opacity-80" />
                       <PlayCircle size={32} className="absolute text-white/80" />
                    </div>
                  ) : (
                    <img 
                      src={item.url} 
                      alt={item.prompt || 'Imagem gerada'} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  )}
                  
                  {/* Overlay Actions */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                     
                     <button
                       onClick={(e) => handleDownload(item.url, `download-${item.id}.${item.type === 'video' ? 'mp4' : 'png'}`, e)}
                       className="p-1.5 bg-white/20 backdrop-blur-sm hover:bg-white text-white hover:text-sky-600 rounded-full transition-colors"
                       title="Baixar"
                     >
                       <Download size={18} />
                     </button>
                     <button 
                       onClick={(e) => handleDelete(item.id, item.url, e)}
                       className="p-1.5 bg-white/20 backdrop-blur-sm hover:bg-red-500 text-white rounded-full transition-colors"
                       title="Excluir"
                     >
                       <Trash2 size={18} />
                     </button>
                  </div>

                  {/* Badge Tipo */}
                  <div className="absolute top-2 left-2">
                     {item.type === 'video' ? (
                       <span className="bg-purple-500/80 backdrop-blur-sm text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-1">
                         <Video size={9} /> VÍDEO
                       </span>
                     ) : (
                       <span className="bg-sky-500/80 backdrop-blur-sm text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-1">
                         <ImageIcon size={9} /> IMAGEM
                       </span>
                     )}
                  </div>
               </div>

               {/* Info */}
               <div className="p-3 flex-1 flex flex-col">
                  <p className="text-[10px] text-slate-400 mb-1">{item.created_at}</p>
                  <p className="text-xs text-slate-700 font-medium line-clamp-3 leading-relaxed" title={item.prompt}>
                    {item.prompt || 'Sem descrição'}
                  </p>
               </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 bg-white rounded-2xl border border-dashed border-slate-200">
           <div className="bg-sky-50 p-4 rounded-full mb-4">
              <ImageIcon size={32} className="text-sky-400" />
           </div>
           <h3 className="text-lg font-bold text-slate-700 mb-1">Galeria Vazia</h3>
           <p className="text-slate-500 text-sm max-w-xs text-center mb-6">
              Você ainda não gerou conteúdos. Use as ferramentas do Dashboard para criar.
           </p>
           <button 
             onClick={() => setShowSqlModal(true)}
             className="text-xs text-slate-400 hover:text-sky-500 underline"
           >
             Problemas? Configurar Banco de Dados
           </button>
        </div>
      )}

      {/* SQL Modal for Setup */}
      {showSqlModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full flex flex-col max-h-[90vh]">
             <div className="p-6 border-b border-slate-100 bg-slate-50 rounded-t-xl">
               <h3 className="text-xl font-bold text-sky-600 flex items-center gap-2">
                 <Database /> Configuração da Galeria e Storage
               </h3>
             </div>
             <div className="p-6 overflow-y-auto">
               <p className="text-slate-600 mb-4 text-sm">
                 Para a galeria funcionar completamente (inserir e excluir), você precisa configurar as políticas da tabela <code>conteudos_gerados</code> e do <strong>Storage</strong>.
               </p>
               
               <div className="bg-slate-900 text-slate-200 p-4 rounded-lg font-mono text-xs overflow-x-auto mb-4 relative group">
                 <pre className="whitespace-pre-wrap">{sqlScript}</pre>
                 <button 
                   onClick={() => navigator.clipboard.writeText(sqlScript)}
                   className="absolute top-2 right-2 bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded text-xs transition-opacity font-medium"
                 >
                   Copiar
                 </button>
               </div>
               
               <div className="flex gap-3 text-sm text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-200">
                 <Terminal size={16} className="shrink-0 mt-0.5" />
                 <div>Rode este código no SQL Editor do Supabase.</div>
               </div>
             </div>
             <div className="p-6 border-t border-slate-100 flex justify-end">
               <button onClick={() => setShowSqlModal(false)} className="bg-slate-200 hover:bg-slate-300 text-slate-800 px-6 py-2 rounded-lg font-medium">
                 Fechar
               </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GalleryPage;