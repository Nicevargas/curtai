
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Credits from './pages/Credits';
import Profile from './pages/Profile';
import CalendarPage from './pages/CalendarPage';
import GalleryPage from './pages/GalleryPage';
import HistoryPage from './pages/HistoryPage';
import { AuthPage } from './pages/Auth';
import { CreatePostModal, AddNewsModal } from './components/Modals';
import { User } from './types';
import { supabase } from './lib/supabase';
import { getCurrentProfile, signOut } from './services/authService';
import { Loader2, AlertCircle, Database, X, Copy, Check } from 'lucide-react';

const App: React.FC = () => {
  const [session, setSession] = useState<any>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState(false);
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [isAddNewsOpen, setIsAddNewsOpen] = useState(false);
  
  // Db Help State for Error Screen
  const [showDbHelp, setShowDbHelp] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  
  // State to control which tab opens in the modal
  const [createPostTab, setCreatePostTab] = useState<'image' | 'ugc' | 'video-long'>('image');

  useEffect(() => {
    // Check active session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) {
        fetchProfile();
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      if (session) {
        // Se o usuário acabou de logar, força ir para o Dashboard
        if (event === 'SIGNED_IN') {
           window.location.hash = '/';
        }

        setLoading(true);
        fetchProfile();
      } else {
        setUser(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchProfile = async () => {
    try {
      const profile = await getCurrentProfile();
      if (profile) {
        setUser(profile);
        setAuthError(false);
      } else {
        // Session exists but profile missing (DB error or sync issue)
        console.error("Session found but profile missing.");
        setAuthError(true);
      }
    } catch (error) {
      console.error("Error loading profile", error);
      setAuthError(true);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut();
    setSession(null);
    setUser(null);
    setAuthError(false);
  };

  // Handler to open Create Post Modal with specific tab
  const handleCreatePost = (tab: 'image' | 'ugc' | 'video-long' = 'image') => {
    setCreatePostTab(tab);
    setIsCreatePostOpen(true);
  };

  const sqlFixScript = `-- SCRIPT DE RECUPERAÇÃO DE PERFIL
-- Se você consegue logar mas vê a tela de erro "Erro de Configuração", rode isto:

-- 1. Garante que a tabela existe
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade not null primary key,
  email text,
  name text,
  category text,
  image_credits integer default 5,
  video_credits integer default 2,
  plan text default 'Teste',
  phone text,
  cnpj_cpf text,
  avatar_url text,
  preferences jsonb default '{}'::jsonb,
  created_at timestamp with time zone default now()
);
alter table public.profiles enable row level security;

-- 2. Cria políticas básicas
create policy "Users can view own profile" on profiles for select using (auth.uid() = id);
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);
create policy "Users can insert own profile" on profiles for insert with check (auth.uid() = id);

-- 3. INSERÇÃO FORÇADA PARA O SEU USUÁRIO ATUAL
-- Isso preenche seu perfil manualmente se o trigger falhou
insert into public.profiles (id, email, name, image_credits, video_credits, plan)
select 
  id, 
  email, 
  raw_user_meta_data->>'name', 
  5, 
  2, 
  'Teste'
from auth.users
where id = auth.uid()
on conflict (id) do nothing;
`;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8fafc]">
        <Loader2 className="w-8 h-8 text-sky-500 animate-spin" />
      </div>
    );
  }

  if (!session) {
    return <AuthPage />;
  }

  // Error state: Session exists but Profile failed to load
  if (authError && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8fafc] p-4">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 max-w-md text-center">
          <div className="bg-red-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="text-red-500 w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-slate-800 mb-2">Erro de Configuração</h2>
          <p className="text-slate-500 mb-6 text-sm">
            Não foi possível carregar seu perfil. Isso geralmente acontece se a tabela 'profiles' não tiver sido criada no Supabase ou se o gatilho falhou.
          </p>
          <div className="flex flex-col gap-3">
             <button 
              onClick={() => setShowDbHelp(true)}
              className="bg-sky-500 hover:bg-sky-600 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
            >
              <Database size={16} /> Configurar Banco e Corrigir
            </button>
            <button 
              onClick={handleLogout}
              className="text-slate-500 hover:text-slate-700 font-medium text-sm underline"
            >
              Voltar para Login
            </button>
          </div>
        </div>

        {/* DB HELP MODAL FOR ERROR SCREEN */}
        {showDbHelp && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full flex flex-col max-h-[85vh]">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center rounded-t-2xl">
              <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <Database className="text-sky-500" /> Correção de Perfil
              </h3>
              <button 
                onClick={() => setShowDbHelp(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto">
              <p className="text-sm text-slate-600 mb-4">
                Copie o script abaixo e execute no <strong>SQL Editor</strong> do Supabase. Ele irá criar seu perfil manualmente e corrigir a tabela.
              </p>

              <div className="bg-slate-900 text-slate-200 p-4 rounded-lg font-mono text-xs overflow-x-auto relative group">
                <pre className="whitespace-pre-wrap">{sqlFixScript}</pre>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(sqlFixScript);
                    setCopySuccess(true);
                    setTimeout(() => setCopySuccess(false), 2000);
                  }}
                  className="absolute top-2 right-2 bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded text-xs transition-opacity font-medium flex items-center gap-1"
                >
                  {copySuccess ? <Check size={14} /> : <Copy size={14} />}
                  {copySuccess ? 'Copiado!' : 'Copiar'}
                </button>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 rounded-b-2xl flex justify-end">
              <button 
                onClick={() => setShowDbHelp(false)}
                className="bg-slate-200 hover:bg-slate-300 text-slate-800 px-6 py-2 rounded-lg font-medium"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      </div>
    );
  }

  // Wait for user profile to be loaded before showing app to avoid null errors
  if (!user) {
     return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8fafc]">
        <Loader2 className="w-8 h-8 text-sky-500 animate-spin" />
      </div>
    );
  }

  return (
    <HashRouter>
      <Layout onLogout={handleLogout}>
        <Routes>
          <Route path="/" element={<Dashboard user={user} onCreatePost={handleCreatePost} />} />
          <Route path="/calendar" element={<CalendarPage onAddNews={() => setIsAddNewsOpen(true)} user={user} />} />
          <Route path="/gallery" element={<GalleryPage user={user} />} />
          <Route path="/history" element={<HistoryPage user={user} />} />
          <Route path="/credits" element={<Credits user={user} onUpdateUser={setUser} />} />
          <Route path="/profile" element={<Profile user={user} onUpdateUser={setUser} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        <CreatePostModal 
          isOpen={isCreatePostOpen} 
          onClose={() => setIsCreatePostOpen(false)}
          user={user} 
          initialTab={createPostTab}
        />
        
        <AddNewsModal 
          isOpen={isAddNewsOpen} 
          onClose={() => setIsAddNewsOpen(false)} 
          user={user}
        />
      </Layout>
    </HashRouter>
  );
};

export default App;
