import { createClient } from '@supabase/supabase-js';

// ⚠️ ATENÇÃO: Substitua estes valores pelos dados do seu projeto Supabase
// Você encontra esses dados em Project Settings -> API
const supabaseUrl = 'https://yunwwchigsruxahcljqf.supabase.co'; 
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl1bnd3Y2hpZ3NydXhhaGNsanFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2MzQ1MDEsImV4cCI6MjA3NTIxMDUwMX0.RZIW06OF2QgLx2wplwGYmzmcANe7Y9f4n_CghDRD9rI';

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    storageKey: 'creathub-auth-token', // Define uma chave única para evitar conflitos no localhost
    storage: window.localStorage, // Garante explicitamente o uso do localStorage
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
});