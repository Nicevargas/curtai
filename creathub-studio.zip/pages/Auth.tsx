
import React, { useState } from 'react';
import { Logo } from '../components/Logo';
import { supabase } from '../lib/supabase';
import { createProfile } from '../services/authService';
import { Loader2, AlertTriangle, CheckCircle, ArrowLeft, Mail, Eye, EyeOff, Database, X, Copy, Check } from 'lucide-react';

type AuthMode = 'login' | 'signup' | 'recovery';

export const AuthPage: React.FC = () => {
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  
  // Database Help Modal State
  const [showDbHelp, setShowDbHelp] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    category: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Lógica específica para Recuperação de Senha
  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);
    
    const cleanEmail = formData.email.trim();

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
        redirectTo: window.location.origin + '/#/profile?reset=true', // Redireciona para o app após clicar no email
      });

      if (error) throw error;

      setSuccessMessage("Um link de recuperação foi enviado para seu email. Verifique sua caixa de entrada (e spam).");
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Erro ao enviar email de recuperação.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);
    
    // Sanitize Email to prevent whitespace errors
    const cleanEmail = formData.email.trim();

    try {
      if (authMode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password: formData.password,
        });
        if (error) throw error;
      } else if (authMode === 'signup') {
        // Sign Up
        const { data, error: signUpError } = await supabase.auth.signUp({
          email: cleanEmail,
          password: formData.password,
          options: {
            data: {
              name: formData.name,
              category: formData.category
            }
          }
        });
        
        if (signUpError) throw signUpError;

        if (data.user) {
          // Try to create profile. Catch error internally to not block flow if user/profile already exists.
          try {
             await createProfile({
              id: data.user.id,
              name: formData.name,
              email: cleanEmail,
              category: formData.category
            });
          } catch (profileErr: any) {
             console.warn("Profile creation note:", profileErr);
             // Continue execution even if profile creation "fails" (e.g. already exists)
          }
          
          // If email confirmation is enabled, show a message
          if (!data.session) {
             setSuccessMessage("Cadastro realizado com sucesso! Verifique sua caixa de entrada (e spam) para confirmar seu email antes de fazer login.");
             setAuthMode('login'); 
             return;
          }
        }
      }
    } catch (err: any) {
      console.error("Auth error:", err);
      
      // Robust error message extraction
      let msg = '';
      if (typeof err === 'string') {
        msg = err;
      } else if (err?.message) {
        msg = err.message;
      } else {
        msg = JSON.stringify(err);
      }
      
      if (msg === '{}' || msg === '{"isTrusted":true}' || !msg) {
        msg = 'Ocorreu um erro inesperado. Verifique sua conexão.';
      }

      // TENTATIVA DE AUTO-LOGIN (Fallback para erro de Trigger/Database)
      // Se o banco retornou erro ao salvar, mas o usuário foi criado no Auth, tentamos logar.
      if (authMode === 'signup' && (msg.includes('Database error saving new user') || msg.includes('conflict') || msg.includes('trigger'))) {
         console.log("Erro de banco detectado no cadastro. Tentando login de recuperação...");
         try {
            const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
                email: cleanEmail,
                password: formData.password
            });
            
            if (!loginError && loginData.session) {
                // Login funcionou! O usuário existe. Ignora o erro anterior.
                return;
            }
         } catch (fallbackErr) {
            console.error("Auto-login fallback failed", fallbackErr);
         }
      }

      // Tradução amigável de erros comuns
      if (msg.includes('Invalid login credentials')) {
        msg = 'Login falhou. Verifique se seu email e senha estão corretos e se você JÁ CONFIRMOU seu email.';
      } else if (msg.includes('User already registered') || msg.includes('unique constraint')) {
        msg = 'Este email já está cadastrado. Tente fazer login.';
      } else if (msg.includes('Database error saving new user')) {
        msg = 'Erro interno do servidor ao criar usuário (provável conflito de Trigger). Tente fazer login, sua conta pode ter sido criada com sucesso.';
      }
      
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  // Títulos e descrições dinâmicas
  const getTitle = () => {
    if (authMode === 'login') return 'Bem-vindo de volta!';
    if (authMode === 'signup') return 'Crie sua conta';
    return 'Recuperar Senha';
  };

  const getDescription = () => {
    if (authMode === 'login') return 'Entre na sua conta para continuar';
    if (authMode === 'signup') return 'Comece a planejar seu conteúdo hoje';
    return 'Enviaremos um link para redefinir sua senha';
  };

  const sqlFixScript = `-- SCRIPT DEFINITIVO DE CORREÇÃO (USER NOT CREATED / MISSING COLUMNS)
-- 1. Cria a tabela (se não existir)
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid references auth.users on delete cascade not null primary key,
  email text,
  name text,
  category text,
  image_credits integer default 5,
  video_credits integer default 2,
  plan text default 'Teste',
  phone text,
  cnpj_cpf text,
  avatar_url text,
  preferences jsonb default '{}'::jsonb,
  created_at timestamp with time zone default now()
);

-- 2. MIGRAÇÃO: Adiciona colunas se faltarem (Corrige erro "column does not exist")
DO $$
BEGIN
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS plan text DEFAULT 'Teste';
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS video_credits integer DEFAULT 2;
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS image_credits integer DEFAULT 5;
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone text;
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cnpj_cpf text;
EXCEPTION
    WHEN others THEN null;
END $$;

-- 3. Habilita RLS (Segurança)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 4. Políticas de Acesso (CRUD)
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- 5. CRIAÇÃO RETROATIVA (Para usuários travados)
INSERT INTO public.profiles (id, email, name, image_credits, video_credits, plan)
SELECT 
  id, 
  email, 
  COALESCE(raw_user_meta_data->>'name', split_part(email, '@', 1)),
  5, 
  2, 
  'Teste'
FROM auth.users
WHERE id NOT IN (SELECT id FROM public.profiles)
ON CONFLICT (id) DO NOTHING;

-- 6. TRIGGER PARA NOVOS USUÁRIOS
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, name, image_credits, video_credits, plan)
  VALUES (
    new.id, 
    new.email, 
    new.raw_user_meta_data->>'name',
    5, 
    2, 
    'Teste'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
`;

  return (
    <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center p-4 relative">
      
      {/* BOTÃO DE AJUDA DO BANCO DE DADOS */}
      <div className="absolute top-4 right-4 z-10">
        <button 
          onClick={() => setShowDbHelp(true)}
          className="flex items-center gap-2 bg-white text-slate-500 hover:text-sky-600 px-4 py-2 rounded-full shadow-sm border border-slate-200 hover:border-sky-300 transition-all text-xs font-bold uppercase tracking-wider"
        >
          <Database size={16} /> Configurar Banco
        </button>
      </div>

      <div className="w-full max-w-[480px] flex flex-col items-center">
         {/* Logo */}
         <div className="mb-8">
            <Logo size="lg" />
         </div>

         <h1 className="text-3xl md:text-4xl font-bold text-sky-600 mb-2 text-center">
           {getTitle()}
         </h1>
         <p className="text-slate-500 mb-8 text-center">
           {getDescription()}
         </p>

         <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 w-full">
            {error && (
              <div className="mb-4 p-4 rounded-lg border border-red-100 bg-red-50 text-red-600 flex gap-3 items-start">
                <AlertTriangle size={20} className="shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="text-sm font-medium break-words leading-relaxed">{error}</div>
                  {/* Se for erro de banco, sugere o botão */}
                  {(error.includes('Database') || error.includes('row-level security') || error.includes('relation')) && (
                     <button 
                       onClick={() => setShowDbHelp(true)} 
                       className="text-xs font-bold underline mt-2 hover:text-red-800"
                     >
                       Clique aqui para corrigir o Banco de Dados
                     </button>
                  )}
                </div>
              </div>
            )}

            {successMessage && (
              <div className="mb-4 p-4 rounded-lg border border-green-200 bg-green-50 text-green-700 flex gap-3">
                <CheckCircle size={20} className="shrink-0 mt-0.5" />
                <div className="text-sm font-medium">{successMessage}</div>
              </div>
            )}

            {/* --- RECOVERY FORM --- */}
            {authMode === 'recovery' ? (
              <form onSubmit={handlePasswordReset} className="space-y-4 animate-fade-in">
                <div>
                  <label className="block text-sm font-medium text-slate-800 mb-2">Email cadastrado</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 text-slate-400" size={16} />
                    <input 
                      type="email" 
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="seu@email.com"
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-700 focus:ring-2 focus:ring-sky-200 outline-none transition-all"
                    />
                  </div>
                </div>

                <button 
                  disabled={isLoading}
                  className="w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 rounded-lg shadow-lg shadow-sky-100 transition-all flex justify-center items-center gap-2 disabled:opacity-70 text-sm mt-2"
                >
                  {isLoading && <Loader2 size={16} className="animate-spin" />}
                  Enviar Link de Recuperação
                </button>

                <div className="text-center mt-4">
                  <button 
                    type="button"
                    onClick={() => { setAuthMode('login'); setError(null); setSuccessMessage(null); }} 
                    className="text-slate-500 hover:text-slate-700 text-sm font-medium flex items-center justify-center gap-2 mx-auto"
                  >
                    <ArrowLeft size={16} /> Voltar ao Login
                  </button>
                </div>
              </form>
            ) : (
              /* --- LOGIN / SIGNUP FORM --- */
              <form onSubmit={handleAuth} className="space-y-4 animate-fade-in">
                
                {authMode === 'signup' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-800 mb-2">Nome completo</label>
                    <input 
                      type="text" 
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Seu nome"
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-700 focus:ring-2 focus:ring-sky-200 outline-none transition-all"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-800 mb-2">Email</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="seu@email.com"
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-700 focus:ring-2 focus:ring-sky-200 outline-none transition-all"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium text-slate-800">Senha</label>
                    {authMode === 'login' && (
                      <button 
                        type="button"
                        onClick={() => { setAuthMode('recovery'); setError(null); }}
                        className="text-xs text-sky-500 hover:text-sky-700 font-medium"
                      >
                        Esqueci minha senha
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"}
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                      placeholder="••••••••"
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-3 pr-10 py-2 text-sm text-slate-700 focus:ring-2 focus:ring-sky-200 outline-none transition-all placeholder:text-slate-300"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-md hover:bg-slate-100"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {authMode === 'signup' && <p className="text-xs text-slate-400 mt-1">Mínimo 6 caracteres</p>}
                </div>

                {authMode === 'signup' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-slate-800 mb-2">Categoria de Interesse</label>
                      <select 
                        name="category"
                        value={formData.category}
                        onChange={handleChange}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-500 focus:ring-2 focus:ring-sky-200 outline-none transition-all appearance-none"
                      >
                        <option value="">Selecione sua área de interesse</option>
                        <option value="Tecnologia">Tecnologia</option>
                        <option value="Negócios">Negócios</option>
                        <option value="Saúde">Saúde</option>
                        <option value="Educação">Educação</option>
                        <option value="Entretenimento">Entretenimento</option>
                        <option value="Esportes">Esportes</option>
                        <option value="Política">Política</option>
                        <option value="Ciência">Ciência</option>
                      </select>
                    </div>
                  </>
                )}

                <button 
                  disabled={isLoading}
                  className="w-full bg-sky-400 hover:bg-sky-500 text-white font-bold py-2 text-sm rounded-lg shadow-lg shadow-sky-100 transition-all mt-4 flex justify-center items-center gap-2 disabled:opacity-70"
                >
                  {isLoading && <Loader2 size={16} className="animate-spin" />}
                  {authMode === 'login' ? 'Entrar' : 'Criar conta'}
                </button>
              </form>
            )}

            {/* Toggle Login/Signup Links (Only shown if not in recovery) */}
            {authMode !== 'recovery' && (
              <div className="mt-6 text-center text-sm text-slate-500">
                 {authMode === 'login' ? 'Não tem uma conta?' : 'Já tem uma conta?'}
                 <button 
                   onClick={() => { setAuthMode(authMode === 'login' ? 'signup' : 'login'); setError(null); setSuccessMessage(null); }} 
                   className="text-sky-500 font-medium ml-1 hover:underline"
                 >
                   {authMode === 'login' ? 'Cadastre-se' : 'Faça login'}
                 </button>
              </div>
            )}
         </div>
         
         {authMode !== 'login' && authMode !== 'recovery' && (
           <button onClick={() => setAuthMode('login')} className="mt-8 text-slate-400 hover:text-slate-600 text-sm transition-colors">
             ← Voltar para home
           </button>
         )}
      </div>

      {/* SQL CONFIG MODAL (OVERLAY) */}
      {showDbHelp && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full flex flex-col max-h-[85vh]">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center rounded-t-2xl">
              <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <Database className="text-sky-500" /> Configuração do Banco
              </h3>
              <button 
                onClick={() => setShowDbHelp(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto">
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-lg mb-4 text-sm text-amber-900">
                <p className="font-bold mb-1">Está com erro "User not found" ou "Database Error"?</p>
                <p>Isso acontece porque a tabela de usuários (profiles) ou o Gatilho automático (Trigger) não foram criados no Supabase.</p>
                <p className="mt-2">Copie o código abaixo e execute no <strong>SQL Editor</strong> do seu painel Supabase.</p>
              </div>

              <div className="bg-slate-900 text-slate-200 p-4 rounded-lg font-mono text-xs overflow-x-auto relative group">
                <pre className="whitespace-pre-wrap">{sqlFixScript}</pre>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(sqlFixScript);
                    setCopySuccess(true);
                    setTimeout(() => setCopySuccess(false), 2000);
                  }}
                  className="absolute top-2 right-2 bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded text-xs transition-opacity font-medium flex items-center gap-1"
                >
                  {copySuccess ? <Check size={14} /> : <Copy size={14} />}
                  {copySuccess ? 'Copiado!' : 'Copiar'}
                </button>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 rounded-b-2xl flex justify-end">
              <button 
                onClick={() => setShowDbHelp(false)}
                className="bg-slate-200 hover:bg-slate-300 text-slate-800 px-6 py-2 rounded-lg font-medium"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
