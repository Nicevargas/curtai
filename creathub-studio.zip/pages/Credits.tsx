
import React, { useState, useEffect } from 'react';
import { Image, Video, Plus, Loader2, MessageCircle, AlertCircle, ExternalLink, CreditCard, Database, X, Copy, Check, CheckCircle2, RefreshCw } from 'lucide-react';
import { User, CreditPackage } from '../types';
import { getCreditPackages } from '../services/creditsService';
import { PaymentModal } from '../components/Modals';
import { getCurrentProfile } from '../services/authService';

interface CreditsProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

const Credits: React.FC<CreditsProps> = ({ user, onUpdateUser }) => {
  const [packages, setPackages] = useState<CreditPackage[]>([]);
  const [loadingPackages, setLoadingPackages] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // States for Payment Modal
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<CreditPackage | null>(null);
  
  // SQL Modal State
  const [showSqlModal, setShowSqlModal] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  
  // Load packages from DB
  useEffect(() => {
    const loadPackages = async () => {
      try {
        const data = await getCreditPackages();
        if (data && data.length > 0) {
           setPackages(data);
           setError(null);
        } else {
           setPackages([]);
        }
      } catch (err: any) {
        console.error("Erro ao carregar pacotes:", err);
        setError("Não foi possível carregar os planos. Verifique a configuração do banco de dados.");
        if (err.message?.includes('does not exist') || err.code === '42P01') {
           setShowSqlModal(true);
        }
      } finally {
        setLoadingPackages(false);
      }
    };
    loadPackages();
  }, []);

  const handleBuyCredits = (pkg: CreditPackage) => {
    setSelectedPackage(pkg);
    setIsPaymentModalOpen(true);
  };

  const handleRefreshBalance = async () => {
    setIsRefreshing(true);
    try {
      const updatedProfile = await getCurrentProfile();
      if (updatedProfile) {
        onUpdateUser(updatedProfile);
      }
    } catch (error) {
      console.error("Erro ao atualizar saldo:", error);
    } finally {
      setTimeout(() => setIsRefreshing(false), 800);
    }
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(sqlScript);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const sqlScript = `
-- 1. Criação da Tabela de Perfis (Fundamental)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID REFERENCES auth.users NOT NULL PRIMARY KEY,
    name TEXT,
    email TEXT,
    category TEXT,
    image_credits INTEGER DEFAULT 5,
    video_credits INTEGER DEFAULT 2,
    plan TEXT DEFAULT 'Teste',
    cnpj_cpf TEXT,
    phone TEXT,
    avatar_url TEXT,
    preferences JSONB DEFAULT '{}'::jsonb
);

-- 1.1 MIGRAÇÃO DE COLUNAS (Evita erro "column does not exist")
DO $$
BEGIN
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS plan TEXT DEFAULT 'Teste';
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT;
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cnpj_cpf TEXT;
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS image_credits INTEGER DEFAULT 5;
    ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS video_credits INTEGER DEFAULT 2;
EXCEPTION
    WHEN others THEN null;
END $$;

-- 1.2 Habilita RLS em Profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 1.3 Políticas para Profiles
DROP POLICY IF EXISTS "Users can read own profile" ON public.profiles;
CREATE POLICY "Users can read own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- 2. Tabela de Pacotes de Créditos (Planos)
CREATE TABLE IF NOT EXISTS public.credit_packages (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    price NUMERIC(10,2) NOT NULL,
    image_credits INTEGER DEFAULT 0,
    video_credits INTEGER DEFAULT 0,
    price_id TEXT, 
    popular BOOLEAN DEFAULT false,
    best_value BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 2.1 Seed dos Planos
INSERT INTO public.credit_packages (name, price, image_credits, video_credits, popular, best_value)
SELECT 'Básico', 29.90, 50, 5, false, false
WHERE NOT EXISTS (SELECT 1 FROM public.credit_packages);

INSERT INTO public.credit_packages (name, price, image_credits, video_credits, popular, best_value)
SELECT 'Pro', 59.90, 150, 20, true, false
WHERE NOT EXISTS (SELECT 1 FROM public.credit_packages WHERE name = 'Pro');

INSERT INTO public.credit_packages (name, price, image_credits, video_credits, popular, best_value)
SELECT 'Premium', 99.90, 400, 50, false, true
WHERE NOT EXISTS (SELECT 1 FROM public.credit_packages WHERE name = 'Premium');

-- 3. Tabela de Compras (Registro de Transações)
CREATE TABLE IF NOT EXISTS public.credit_purchases (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) NOT NULL,
    package_id UUID REFERENCES public.credit_packages(id),
    amount_paid NUMERIC(10,2),
    image_credits_purchased INTEGER DEFAULT 0, 
    video_credits_purchased INTEGER DEFAULT 0, 
    status TEXT DEFAULT 'pending',
    external_id TEXT, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 3.1 CORREÇÃO DE COLUNAS (Legado)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='credit_purchases' AND column_name='image_credits_purchased') THEN
        ALTER TABLE public.credit_purchases ADD COLUMN image_credits_purchased INTEGER DEFAULT 0;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='credit_purchases' AND column_name='video_credits_purchased') THEN
        ALTER TABLE public.credit_purchases ADD COLUMN video_credits_purchased INTEGER DEFAULT 0;
    END IF;
END $$;

-- 4. Tabela de Histórico de Uso
CREATE TABLE IF NOT EXISTS public.credit_history (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) NOT NULL,
    type TEXT NOT NULL, 
    amount INTEGER NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 5. FUNÇÃO RPC: Debitar Créditos
CREATE OR REPLACE FUNCTION public.deduct_credits_atomic(
    p_user_id UUID,
    p_type TEXT,
    p_amount INTEGER,
    p_description TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    current_balance INTEGER;
BEGIN
    IF p_type = 'image' THEN
        SELECT image_credits INTO current_balance FROM public.profiles WHERE id = p_user_id;
        IF current_balance < p_amount THEN RETURN FALSE; END IF;
        UPDATE public.profiles SET image_credits = image_credits - p_amount WHERE id = p_user_id;
    ELSE
        SELECT video_credits INTO current_balance FROM public.profiles WHERE id = p_user_id;
        IF current_balance < p_amount THEN RETURN FALSE; END IF;
        UPDATE public.profiles SET video_credits = video_credits - p_amount WHERE id = p_user_id;
    END IF;

    INSERT INTO public.credit_history (user_id, type, amount, description)
    VALUES (p_user_id, p_type, p_amount, p_description);

    RETURN TRUE;
END;
$$;

-- 6. TRIGGER INTELIGENTE: Atualiza Créditos e Histórico
CREATE OR REPLACE FUNCTION public.handle_payment_status_change()
RETURNS TRIGGER AS $$
DECLARE
    v_img_amount INTEGER;
    v_vid_amount INTEGER;
    v_pkg_record RECORD;
    v_pkg_name TEXT := 'Créditos';
BEGIN
    -- 1. Tenta pegar os valores da própria linha inserida/atualizada
    v_img_amount := COALESCE(NEW.image_credits_purchased, 0);
    v_vid_amount := COALESCE(NEW.video_credits_purchased, 0);

    -- 2. Se a linha estiver zerada, busca do PACOTE
    IF v_img_amount = 0 AND v_vid_amount = 0 AND NEW.package_id IS NOT NULL THEN
        SELECT * INTO v_pkg_record FROM public.credit_packages WHERE id = NEW.package_id;
        IF FOUND THEN
            v_img_amount := v_pkg_record.image_credits;
            v_vid_amount := v_pkg_record.video_credits;
            v_pkg_name := v_pkg_record.name;
        END IF;
    END IF;

    -- 3. Executa a lógica apenas se mudou para 'paid'
    IF NEW.status = 'paid' AND (OLD.status IS NULL OR OLD.status != 'paid') THEN
        UPDATE public.profiles
        SET 
            image_credits = COALESCE(image_credits, 0) + v_img_amount,
            video_credits = COALESCE(video_credits, 0) + v_vid_amount
        WHERE id = NEW.user_id;

        INSERT INTO public.credit_history (user_id, type, amount, description)
        VALUES (
            NEW.user_id, 
            'system', 
            (v_img_amount + v_vid_amount), 
            'Compra Confirmada: ' || v_pkg_name
        );
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Reaplica o gatilho
DROP TRIGGER IF EXISTS on_payment_paid ON public.credit_purchases;
CREATE TRIGGER on_payment_paid
AFTER UPDATE ON public.credit_purchases
FOR EACH ROW
EXECUTE FUNCTION public.handle_payment_status_change();

-- 7. Políticas de Segurança Finais
ALTER TABLE public.credit_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.credit_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.credit_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public read packages" ON public.credit_packages;
CREATE POLICY "Public read packages" ON public.credit_packages FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users see own purchases" ON public.credit_purchases;
CREATE POLICY "Users see own purchases" ON public.credit_purchases FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users see own history" ON public.credit_history;
CREATE POLICY "Users see own history" ON public.credit_history FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users create pending purchases" ON public.credit_purchases;
CREATE POLICY "Users create pending purchases" ON public.credit_purchases FOR INSERT WITH CHECK (auth.uid() = user_id);
`;

  return (
    <div className="space-y-8 animate-fade-in pb-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 mb-1">Planos e Créditos</h1>
          <p className="text-slate-500">Gerencie seu saldo e recarregue para criar mais conteúdo</p>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={handleRefreshBalance}
                className="flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-sky-600 bg-white border border-slate-200 hover:border-sky-300 px-4 py-2 rounded-lg transition-all"
                title="Atualizar Saldo"
            >
                <RefreshCw size={16} className={isRefreshing ? "animate-spin" : ""} /> 
                {isRefreshing ? 'Atualizando...' : 'Atualizar Saldo'}
            </button>
            <button 
            onClick={() => setShowSqlModal(true)}
            className="flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-sky-600 bg-white border border-slate-200 hover:border-sky-300 px-4 py-2 rounded-lg transition-all"
            >
            <Database size={16} /> Configurar Banco de Dados
            </button>
        </div>
      </div>

      {/* Credit Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4 relative overflow-hidden group">
          <div className="absolute right-0 top-0 w-24 h-24 bg-sky-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
          <div className="bg-sky-50 p-3 rounded-full text-sky-500 relative z-10">
            <Image size={24} />
          </div>
          <div className="relative z-10">
            <p className="text-sm text-slate-500 font-medium">Créditos de Imagem</p>
            <p className="text-3xl font-bold text-slate-800">{user.imageCredits}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4 relative overflow-hidden group">
          <div className="absolute right-0 top-0 w-24 h-24 bg-purple-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
          <div className="bg-purple-50 p-3 rounded-full text-purple-500 relative z-10">
            <Video size={24} />
          </div>
          <div className="relative z-10">
            <p className="text-sm text-slate-500 font-medium">Créditos de Vídeo</p>
            <p className="text-3xl font-bold text-slate-800">{user.videoCredits}</p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-sky-500 to-blue-600 p-6 rounded-xl shadow-md text-white flex flex-col items-center justify-center text-center relative overflow-hidden">
           <div className="absolute inset-0 bg-white/10 opacity-0 hover:opacity-100 transition-opacity"></div>
           <p className="text-sky-100 text-sm mb-1 font-medium">Precisa de mais?</p>
           <button 
             onClick={() => {
               const element = document.getElementById('plans-section');
               element?.scrollIntoView({ behavior: 'smooth' });
             }}
             className="bg-white text-sky-600 px-6 py-2.5 rounded-lg font-bold hover:bg-sky-50 transition-all flex items-center gap-2 shadow-sm"
           >
             <Plus size={18} />
             Recarregar Agora
           </button>
        </div>
      </div>

      {error && (
         <div className="bg-amber-50 text-amber-600 p-4 rounded-lg flex items-center justify-between gap-2 text-sm border border-amber-100">
            <div className="flex items-center gap-2">
               <AlertCircle size={16} /> {error}
            </div>
            <button 
              onClick={() => setShowSqlModal(true)}
              className="underline font-bold hover:text-amber-700"
            >
              Corrigir agora
            </button>
         </div>
      )}

      {/* Pricing Plans */}
      <div id="plans-section" className="pt-8 border-t border-slate-100">
         <div className="text-center mb-10">
           <h2 className="text-3xl font-bold text-slate-800 mb-2">Planos Disponíveis</h2>
           <p className="text-slate-500">Pagamento seguro via PIX ou Cartão.</p>
         </div>

         {loadingPackages ? (
            <div className="flex justify-center py-12">
               <Loader2 className="w-8 h-8 text-sky-500 animate-spin" />
            </div>
         ) : packages.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 items-start">
                {packages.map((pkg) => {
                  return (
                    <PricingCard 
                      key={pkg.id}
                      name={pkg.name} 
                      price={pkg.price.toString()} 
                      imageCredits={pkg.image_credits} 
                      videoCredits={pkg.video_credits} 
                      popular={pkg.popular}
                      bestValue={pkg.best_value}
                      onBuy={() => handleBuyCredits(pkg)}
                    />
                  );
                })}
            </div>
         ) : (
            <div className="text-center py-12 bg-slate-50 rounded-xl border-2 border-dashed border-slate-200">
               <Database className="mx-auto text-slate-300 mb-3" size={32} />
               <p className="text-slate-500 mb-4 font-medium">Nenhum plano encontrado no banco de dados.</p>
               <button 
                 onClick={() => setShowSqlModal(true)}
                 className="bg-sky-500 hover:bg-sky-600 text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors"
               >
                 Criar Planos Padrão
               </button>
            </div>
         )}
         
         {/* Business Card - Shown ONLY to specific test user */}
         {user.email === 'eunicelvargas@gmail.com' && (
           <div className="mt-12 max-w-4xl mx-auto bg-slate-900 rounded-2xl p-8 relative overflow-hidden text-white shadow-xl">
              <div className="absolute top-0 right-0 p-32 bg-sky-500/20 rounded-full blur-3xl -mr-16 -mt-16"></div>
              <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="text-center md:text-left">
                     <div className="inline-block bg-sky-500 text-white text-xs font-bold px-3 py-1 rounded-full mb-3 uppercase tracking-wider">
                        Business
                     </div>
                     <h3 className="text-2xl font-bold mb-2">Plano Empresarial Personalizado</h3>
                     <p className="text-slate-300 mb-4 max-w-md">
                        Tenha acesso exclusivo a automações avançadas, Avatar Sora2 configurado e suporte prioritário 24/7.
                     </p>
                     <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-sm text-slate-300 text-left">
                        <li className="flex items-center gap-2"><CheckCircle2 size={16} className="text-sky-400" /> Configuração Avatar Sora2</li>
                        <li className="flex items-center gap-2"><CheckCircle2 size={16} className="text-sky-400" /> Gerenciador de Post</li>
                        <li className="flex items-center gap-2"><CheckCircle2 size={16} className="text-sky-400" /> Automação de Redes</li>
                        <li className="flex items-center gap-2"><CheckCircle2 size={16} className="text-sky-400" /> Suporte Dedicado</li>
                     </ul>
                  </div>
                  <div className="shrink-0">
                    <button 
                      onClick={() => window.open('https://wa.me/5551985413413', '_blank')}
                      className="bg-sky-500 text-white px-8 py-4 rounded-xl text-sm font-bold hover:bg-sky-400 transition-colors flex items-center gap-2 shadow-lg shadow-sky-900/50"
                    >
                      <MessageCircle size={18} /> Falar com Especialista
                    </button>
                  </div>
              </div>
           </div>
         )}
      </div>

      {/* Payment Modal */}
      <PaymentModal 
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        user={user}
        selectedPackage={selectedPackage}
        onUpdateUser={onUpdateUser}
      />

      {/* SQL Config Modal */}
      {showSqlModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full flex flex-col max-h-[85vh]">
             <div className="p-6 border-b border-slate-100 bg-slate-50/50 rounded-t-2xl flex justify-between items-center">
               <div>
                  <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <Database className="text-sky-500" size={24} /> Configuração do Sistema de Créditos
                  </h3>
                  <p className="text-sm text-slate-500 mt-1">Execute este script no Supabase para habilitar automação de pagamentos.</p>
               </div>
               <button onClick={() => setShowSqlModal(false)} className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-100 rounded-lg transition-colors">
                  <X size={24} />
               </button>
             </div>
             
             <div className="p-6 overflow-y-auto custom-scrollbar flex-1 bg-slate-50">
               <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                  <div className="flex justify-between items-center px-4 py-2 bg-slate-100 border-b border-slate-200">
                     <span className="text-xs font-mono text-slate-500">schema.sql</span>
                     <button 
                       onClick={handleCopySql}
                       className="text-xs font-bold text-sky-600 flex items-center gap-1.5 hover:text-sky-700 transition-colors px-2 py-1 rounded hover:bg-white"
                     >
                       {copySuccess ? <Check size={14} /> : <Copy size={14} />}
                       {copySuccess ? 'Copiado!' : 'Copiar Script'}
                     </button>
                  </div>
                  <pre className="p-4 text-xs font-mono text-slate-700 overflow-x-auto whitespace-pre-wrap leading-relaxed">
                    {sqlScript}
                  </pre>
               </div>
               
               <div className="mt-6 space-y-3">
                  <h4 className="font-bold text-slate-700 text-sm">O que este script faz?</h4>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-600">
                     <li className="col-span-1 md:col-span-2 flex items-start gap-2 bg-green-50 p-2 rounded-lg border border-green-100">
                        <CheckCircle2 size={14} className="text-green-500 mt-0.5 shrink-0" />
                        <span><strong>CRIA TABELA PROFILES:</strong> Garante que a tabela de usuários exista com colunas de créditos.</span>
                     </li>
                     <li className="flex items-start gap-2">
                        <CheckCircle2 size={14} className="text-green-500 mt-0.5 shrink-0" />
                        <span>Cria a tabela <strong>credit_packages</strong> e insere os planos.</span>
                     </li>
                     <li className="flex items-start gap-2">
                        <CheckCircle2 size={14} className="text-green-500 mt-0.5 shrink-0" />
                        <span>Cria tabela <strong>credit_purchases</strong> com colunas <strong>image_credits_purchased</strong> e <strong>video_credits_purchased</strong>.</span>
                     </li>
                     <li className="col-span-1 md:col-span-2 flex items-start gap-2 bg-sky-50 p-2 rounded-lg border border-sky-100">
                        <CheckCircle2 size={14} className="text-sky-500 mt-0.5 shrink-0" />
                        <span><strong>GATILHO AUTOMÁTICO:</strong> Detecta pagamento (status='paid') e soma os créditos no perfil, salvando no histórico.</span>
                     </li>
                  </ul>
               </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

const PricingCard: React.FC<{
  name: string;
  price: string;
  imageCredits: number;
  videoCredits: number;
  popular?: boolean;
  bestValue?: boolean;
  onBuy: () => void;
}> = ({ name, price, imageCredits, videoCredits, popular, bestValue, onBuy }) => {
  return (
    <div className={`bg-white rounded-xl p-6 relative border transition-all duration-300 flex flex-col h-full group ${
      bestValue 
        ? 'border-sky-500 shadow-xl shadow-sky-100 ring-1 ring-sky-500 scale-105 z-10' 
        : 'border-slate-100 shadow-sm hover:shadow-md hover:-translate-y-1'
    }`}>
      {popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-sky-400 to-blue-500 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
          Mais Popular
        </div>
      )}
      {bestValue && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
          Melhor Custo-Benefício
        </div>
      )}

      <h3 className="text-lg font-bold text-center text-slate-800 mb-2 capitalize mt-2">{name}</h3>
      <div className="text-center mb-6">
        <span className="text-sm text-slate-400 align-top mr-1">R$</span>
        <span className="text-4xl font-bold text-slate-800 tracking-tight">{price}</span>
      </div>

      <div className="space-y-4 text-sm text-slate-600 mb-8 flex-1 border-t border-slate-50 pt-6">
        <div className="flex items-center gap-3">
          <div className="bg-sky-50 p-2 rounded-lg text-sky-500"><Image size={16} /></div>
          <span><strong>{imageCredits}</strong> créditos de imagem</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-purple-50 p-2 rounded-lg text-purple-500"><Video size={16} /></div>
          <span><strong>{videoCredits}</strong> créditos de vídeo</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-slate-50 p-2 rounded-lg text-slate-400"><CheckCircle2 size={16} /></div>
          <span className="text-slate-500">Suporte prioritário</span>
        </div>
      </div>

      <button 
        onClick={onBuy}
        className={`w-full py-3 rounded-lg text-sm font-bold transition-all flex items-center justify-center gap-2 ${
           bestValue 
              ? 'bg-sky-500 text-white hover:bg-sky-600 shadow-lg shadow-sky-200' 
              : 'bg-slate-800 text-white hover:bg-slate-900 shadow-md hover:shadow-lg'
        }`}
      >
        <CreditCard size={18} /> Comprar Agora
      </button>
    </div>
  );
};

export default Credits;
