
import React, { useState, useEffect, useRef } from 'react';
import { X, Upload, Image as ImageIcon, Film, Info, Loader2, Wand2, Save, ExternalLink, Trash2, FileImage, CheckCircle2, UserCircle, Layers, MonitorPlay, Clapperboard, Play, Copy, ArrowDown, FileText, Link as LinkIcon, AlertTriangle, Video, CreditCard, Phone, PlaySquare, History, Youtube, Send, Sparkles } from 'lucide-react';
import { generateNewsSummary, generatePostCaption } from '../services/geminiService';
import { User, NewsItem, CreditPackage } from '../types';
import { updateNews, createNews } from '../services/newsService';
import { deductCredits } from '../services/creditsService';
import { updateProfile } from '../services/authService';
import { Link } from 'react-router-dom';

// Estilos predefinidos para Avatar
const avatarStyles = [
  { 
    id: 'office', 
    name: 'Escritório Moderno', 
    prompt: 'Cenário de escritório corporativo moderno, com pessoas trabalhando focadas ao fundo, ambiente movimentado e profissional, iluminação de estúdio.', 
    img: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=300&q=80' 
  },
  { 
    id: 'studio', 
    name: 'Estúdio de Notícias', 
    prompt: 'Cenário de estúdio de telejornal, bancada moderna, fundo azulado profissional.', 
    // Link atualizado para uma imagem funcional de background corporativo/jornalístico
    img: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=300&q=80' 
  },
  { 
    id: 'home', 
    name: 'Home Office Casual', 
    prompt: 'Ambiente de casa aconchegante, fundo desfocado, luz natural, estilo casual e amigável.', 
    img: 'https://images.unsplash.com/photo-1593642532400-2682810df593?auto=format&fit=crop&w=300&q=80' 
  },
  { 
    id: 'tech', 
    name: 'Tech / Futurista', 
    prompt: 'Fundo tecnológico abstrato com luzes neon suaves, estilo inovador e digital.', 
    img: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=300&q=80' 
  },
];

// Generic Modal Wrapper
const ModalWrapper: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: React.ReactNode;
  footer: React.ReactNode;
  maxWidth?: string;
}> = ({ isOpen, onClose, title, description, children, footer, maxWidth = "max-w-2xl" }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className={`bg-white rounded-2xl shadow-2xl w-full ${maxWidth} flex flex-col max-h-[90vh]`}>
        <div className="p-6 border-b border-slate-100 flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold text-slate-800">{title}</h2>
            {description && <p className="text-slate-500 text-sm mt-1">{description}</p>}
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1">
            <X size={20} />
          </button>
        </div>
        <div className="p-6 overflow-y-auto flex-1 custom-scrollbar">
          {children}
        </div>
        <div className="p-6 border-t border-slate-100 bg-slate-50/50 rounded-b-2xl">
          {footer}
        </div>
      </div>
    </div>
  );
};

// Helper to check for network/CORS errors
const isCorsOrNetworkError = (error: any) => {
  const msg = (error?.message || '').toLowerCase();
  return (
    error instanceof TypeError ||
    error.name === 'TypeError' ||
    msg.includes('failed to fetch') ||
    msg.includes('networkerror') ||
    msg.includes('network request failed') ||
    msg.includes('cors') ||
    msg.includes('load failed') || // Safari
    msg.includes('fetch')
  );
};

// Payment Modal (Checkout Asaas)
export const PaymentModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  selectedPackage: CreditPackage | null;
  onUpdateUser?: (user: User) => void;
}> = ({ isOpen, onClose, user, selectedPackage, onUpdateUser }) => {
  const [cpfCnpj, setCpfCnpj] = useState('');
  const [phone, setPhone] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  // Pre-fill fields from user profile when modal opens
  useEffect(() => {
    if (isOpen && user) {
      if (user.cnpj_cpf) setCpfCnpj(String(user.cnpj_cpf));
      if (user.phone) setPhone(String(user.phone));
    }
  }, [isOpen, user]);

  // Máscara simples para CPF/CNPJ
  const handleDocChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    
    if (value.length <= 11) {
      // CPF Mask: 000.000.000-00
      value = value.replace(/(\d{3})(\d)/, '$1.$2');
      value = value.replace(/(\d{3})(\d)/, '$1.$2');
      value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    } else {
      // CNPJ Mask: 00.000.000/0000-00
      value = value.substring(0, 14); // Limit to 14 digits
      value = value.replace(/^(\d{2})(\d)/, '$1.$2');
      value = value.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
      value = value.replace(/\.(\d{3})(\d)/, '.$1/$2');
      value = value.replace(/(\d{4})(\d)/, '$1-$2');
    }
    
    setCpfCnpj(value);
  };

  // Máscara simples para Telefone (Celular/Fixo)
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);

    if (value.length > 10) {
      // (11) 99999-9999
      value = value.replace(/^(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    } else if (value.length > 6) {
      // (11) 9999-9999
      value = value.replace(/^(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
    } else if (value.length > 2) {
      value = value.replace(/^(\d{2})(\d{0,5})/, '($1) $2');
    }
    
    setPhone(value);
  };

  const handlePayment = async () => {
    if (!user || !selectedPackage) return;
    
    // Remove mascara para enviar apenas números
    const cleanDoc = String(cpfCnpj).replace(/\D/g, '');
    const cleanPhone = String(phone).replace(/\D/g, '');
    
    if (cleanDoc.length !== 11 && cleanDoc.length !== 14) {
      alert("Por favor, insira um CPF (11 dígitos) ou CNPJ (14 dígitos) válido.");
      return;
    }

    if (cleanPhone.length < 10) {
      alert("Por favor, insira um telefone válido com DDD.");
      return;
    }

    setIsLoading(true);
    setSuccess(false);

    try {
      // 1. Save phone/cpf to profile to ensure it is pre-filled next time
      try {
        await updateProfile(user.id, {
           phone: phone, 
           cnpj_cpf: cpfCnpj 
        });

        // 2. Update local state immediately to reflect persistence
        if (onUpdateUser) {
           onUpdateUser({
             ...user,
             phone: phone,
             cnpj_cpf: cpfCnpj
           });
        }
      } catch (profileError) {
        console.warn("Could not save profile details:", profileError);
      }

      // 3. Prepare payload for webhook
      const payload = {
        name: user.name,
        email: user.email,
        id_usuario: user.id,
        cpf_cnpj: cleanDoc,
        telefone: cleanPhone,
        plano_nome: selectedPackage.name,
        valor: selectedPackage.price
      };

      console.log("Enviando solicitação de pagamento:", payload);

      // Envia para o Webhook do Asaas
      await fetch('https://n8n-n8n.6wqa93.easypanel.host/webhook/PagtoAsaas', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
        mode: 'cors'
      });

      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
        // MENSAGEM ATUALIZADA
        alert("Solicitação enviada! Consulte seu email e whatsapp para finalizar a transação.");
      }, 2000);

    } catch (error: any) {
      console.error("Erro no pagamento:", error);
      if (isCorsOrNetworkError(error)) {
         setSuccess(true);
         setTimeout(() => {
            setSuccess(false);
            onClose();
            // MENSAGEM ATUALIZADA (FALLBACK)
            alert("Solicitação enviada! Consulte seu email e whatsapp para finalizar a transação.");
         }, 2000);
      } else {
         alert(`Erro ao processar: ${error.message}`);
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (!selectedPackage) return null;

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Finalizar Compra"
      description="Preencha os dados para receber o link de pagamento."
      maxWidth="max-w-md"
      footer={
        <div className="flex flex-col gap-3 w-full">
          {/* AVISO PRÉ-CLIQUE */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-2 mb-2">
            <Info className="text-amber-600 shrink-0 mt-0.5" size={16} />
            <p className="text-xs text-amber-800 font-medium">
               Após clicar em Pagar, consulte seu <strong>E-mail</strong> e <strong>WhatsApp</strong> para acessar o link do Asaas e concluir a transação.
            </p>
          </div>

          <button 
            onClick={handlePayment}
            disabled={isLoading || success || !cpfCnpj || !phone}
            className={`w-full py-2.5 rounded-lg text-white font-bold shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed ${
              success ? 'bg-sky-500 shadow-sky-100' : 'bg-sky-500 hover:bg-sky-600 shadow-sky-100'
            }`}
          >
            {isLoading ? (
              <>
                <Loader2 size={18} className="animate-spin" /> Gerando Pagamento...
              </>
            ) : success ? (
              <>
                <CheckCircle2 size={18} /> Sucesso!
              </>
            ) : (
              <>
                <CreditCard size={18} /> Pagar R$ {selectedPackage.price}
              </>
            )}
          </button>
          <button onClick={onClose} className="w-full py-2 text-sm text-slate-500 hover:text-slate-700">
            Cancelar
          </button>
        </div>
      }
    >
      <div className="space-y-6">
        {/* Resumo do Pedido */}
        <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-slate-500">Plano Selecionado</span>
            <span className="text-sm font-bold text-sky-600 uppercase">{selectedPackage.name}</span>
          </div>
          <div className="flex justify-between items-center border-t border-slate-200 pt-2">
            <span className="text-slate-700 font-bold">Total a pagar</span>
            <span className="text-xl font-bold text-slate-800">R$ {selectedPackage.price}</span>
          </div>
        </div>

        {/* Formulário */}
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">CPF ou CNPJ <span className="text-red-500">*</span></label>
            <input
              type="text"
              value={cpfCnpj}
              onChange={handleDocChange}
              placeholder="000.000.000-00"
              required
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-100 focus:border-sky-400 transition-all font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">Telefone / WhatsApp <span className="text-red-500">*</span></label>
            <div className="relative">
              <Phone size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={phone}
                onChange={handlePhoneChange}
                placeholder="(11) 99999-9999"
                required
                className="w-full border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-100 focus:border-sky-400 transition-all font-mono"
              />
            </div>
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};

// Create Post Modal (Criar Imagens/Posts)
export const CreatePostModal: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  user: User | null;
  initialTab?: 'image' | 'ugc' | 'video-long' | 'video-from-image' | 'restore';
}> = ({ isOpen, onClose, user, initialTab = 'image' }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  
  // Prompt State
  const [prompt, setPrompt] = useState('');
  
  // Author State
  const [author, setAuthor] = useState('');
  
  // Youtube URL State
  const [youtubeUrl, setYoutubeUrl] = useState('');

  // Tipos de Post
  const [postType, setPostType] = useState<'image' | 'ugc' | 'video-long' | 'video-from-image' | 'restore'>(initialTab);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync initialTab when modal opens
  useEffect(() => {
    if (isOpen && initialTab) {
      setPostType(initialTab);
    }
  }, [isOpen, initialTab]);

  const webhooks = {
    image: 'https://n8n-n8n.6wqa93.easypanel.host/webhook/loopdowloandimage',
    ugc: 'https://n8n-n8n.6wqa93.easypanel.host/webhook/videoUgc',
    'video-long': 'https://n8n-n8n.6wqa93.easypanel.host/webhook/videoInsttucional',
    'video-from-image': 'https://n8n-n8n.6wqa93.easypanel.host/webhook/criarImagempvideo',
    restore: 'https://n8n-n8n.6wqa93.easypanel.host/webhook/restaurar'
  };

  useEffect(() => {
    if (!files) return;

    const objectUrls = files.map(file => URL.createObjectURL(file));
    setPreviews(objectUrls);

    return () => {
      objectUrls.forEach(url => URL.revokeObjectURL(url));
    };
  }, [files]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
       const newFiles = Array.from(e.target.files);
       
       // Logic for single file inputs
       if (postType === 'video-from-image') {
          setFiles([newFiles[0]]);
       } else if (postType !== 'video-long') {
          setFiles(prevFiles => [...prevFiles, ...newFiles]);
       }
       setUploadSuccess(false);
       e.target.value = '';
    }
  };

  const removeFile = (index: number) => {
    setFiles(prevFiles => prevFiles.filter((_, i) => i !== index));
  };

  const handleSuccess = () => {
    setUploadSuccess(true);
    setTimeout(() => {
      setFiles([]);
      setPreviews([]);
      setPrompt('');
      setAuthor('');
      setYoutubeUrl('');
      setUploadSuccess(false);
      onClose();
    }, 1500);
  };

  const handleCreate = async () => {
    // 1. Validações Locais
    if (!user) return;
    if (files.length === 0 && (postType === 'image' || postType === 'ugc' || postType === 'video-from-image' || postType === 'restore')) return;
    if (postType === 'ugc' && !prompt.trim()) return;
    if (postType === 'video-long' && !prompt.trim()) return;
    if (postType === 'video-long' && !author.trim()) return; // Validação do autor
    
    // 2. VERIFICAÇÃO ESTRITA DE CRÉDITOS ANTES DE QUALQUER AÇÃO
    // Impede o envio se não houver saldo local
    if (postType === 'image' || postType === 'restore') {
       if (user.imageCredits <= 0) {
          alert(`Saldo insuficiente. Você possui ${user.imageCredits} créditos de IMAGEM. Por favor, recarregue.`);
          return;
       }
    } else {
       // UGC, Video Longo ou Video From Image consomem créditos de vídeo
       if (user.videoCredits <= 0) {
          alert(`Saldo insuficiente. Você possui ${user.videoCredits} créditos de VÍDEO. Por favor, recarregue.`);
          return;
       }
    }

    setIsUploading(true);
    setUploadSuccess(false);

    const webhookUrl = webhooks[postType];
    console.log(`Enviando para Webhook (${postType}):`, webhookUrl);

    try {
      // 3. Enviar para Webhook
      if (postType === 'video-long') {
         // Para vídeo longo, sempre envia JSON (sem arquivo)
         const payload = {
          id_usuario: user.id,
          email: user.email,
          prompt: prompt, // Texto
          author: author, // Autor
          youtube_url: youtubeUrl, // URL Youtube Opcional
          type: 'storyboard'
        };

        await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          mode: 'cors' 
        });
      } else {
        const formData = new FormData();
        files.forEach(file => { formData.append('files', file); });
        formData.append('id_usuario', user.id);
        formData.append('email', user.email);
        
        if (postType === 'video-from-image') {
          formData.append('type', 'video');
        } else if (postType === 'restore') {
          formData.append('type', 'restore');
        } else {
          formData.append('type', postType);
        }

        if (postType === 'ugc') {
          formData.append('prompt', prompt);
        }

        // Removido mode: 'no-cors' para garantir envio correto dos dados
        await fetch(webhookUrl, {
          method: 'POST',
          body: formData
        });
      }

      // 4. Debitar Créditos no Banco (Sucesso no Envio)
      try {
        const creditType = (postType === 'image' || postType === 'restore') ? 'image' : 'video';
        await deductCredits(user.id, creditType, 1, `Criação de Post (${postType})`);
        
        // Atualiza visualmente o saldo local (opcional, para feedback instantâneo)
        if (creditType === 'image') user.imageCredits -= 1;
        else user.videoCredits -= 1;

      } catch (dbError: any) {
        console.error("Erro ao debitar créditos:", dbError);
        // O erro do deductCredits já é tratado no service, mas não interrompe o fluxo de sucesso visual
        // pois o webhook já foi disparado.
      }

      handleSuccess();

    } catch (error: any) {
      console.error("Erro ao criar post:", error);
      if (isCorsOrNetworkError(error)) {
        console.warn("Aviso de CORS/Rede detectado. Assumindo sucesso no envio.");
        // Tenta debitar mesmo com erro de CORS pois geralmente o webhook funciona
        try {
           const creditType = (postType === 'image' || postType === 'restore') ? 'image' : 'video';
           await deductCredits(user.id, creditType, 1, `Criação de Post (${postType})`);
           if (creditType === 'image') user.imageCredits -= 1;
           else user.videoCredits -= 1;
        } catch(e) { console.error("Erro debito fallback", e) }

        handleSuccess();
      } else {
        alert(`Erro ao enviar solicitação: ${error.message}`);
        setIsUploading(false);
      }
    }
  };

  const isButtonDisabled = () => {
    if (isUploading || uploadSuccess) return true;
    if (!user) return true;
    
    // Verificação visual para desabilitar botão se sem créditos
    if ((postType === 'image' || postType === 'restore') && user.imageCredits <= 0) return true;
    if ((postType === 'ugc' || postType === 'video-long' || postType === 'video-from-image') && user.videoCredits <= 0) return true;

    if (postType === 'image' && files.length === 0) return true;
    if (postType === 'restore' && files.length === 0) return true;
    if (postType === 'ugc' && (files.length === 0 || !prompt.trim())) return true;
    if (postType === 'video-long' && (!prompt.trim() || !author.trim())) return true; // Validação de campos obrigatórios
    if (postType === 'video-from-image' && files.length === 0) return true;
    return false;
  };

  const getCreditErrorMsg = () => {
      if ((postType === 'image' || postType === 'restore') && user?.imageCredits <= 0) return "Sem créditos de Imagem";
      if ((postType === 'ugc' || postType === 'video-long' || postType === 'video-from-image') && user?.videoCredits <= 0) return "Sem créditos de Vídeo";
      return null;
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Criar Conteúdo"
      description="Escolha o tipo de conteúdo e preencha as informações"
      maxWidth="max-w-5xl"
      footer={
        <div className="flex justify-end gap-3 items-center">
          {getCreditErrorMsg() && (
             <span className="text-xs text-red-500 font-bold mr-2 bg-red-50 px-2 py-1 rounded">
               {getCreditErrorMsg()}
             </span>
          )}
          <button onClick={onClose} className="px-6 py-2.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 font-medium transition-colors text-sm">
            Cancelar
          </button>
          <button 
            onClick={handleCreate}
            disabled={isButtonDisabled()}
            className={`px-8 py-2.5 rounded-lg font-bold shadow-md transition-colors flex items-center gap-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed ${
              uploadSuccess 
                ? 'bg-sky-500 text-white shadow-sky-100' 
                : 'bg-sky-500 hover:bg-sky-600 text-white shadow-sky-100'
            }`}
          >
            {isUploading ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                Processando...
              </>
            ) : uploadSuccess ? (
              <>
                <CheckCircle2 size={16} />
                Criado!
              </>
            ) : (
              'Criar'
            )}
          </button>
        </div>
      }
    >
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 h-full">
        {/* Lado Esquerdo: Controles e Texto */}
        <div className={`${postType === 'video-long' ? 'md:col-span-12' : 'md:col-span-5'} flex flex-col gap-4 transition-all duration-300`}>
            {/* Seletor de Tipo de Post */}
            <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1.5 rounded-xl">
              <button 
                onClick={() => { setPostType('image'); setFiles([]); }}
                className={`flex flex-col items-center justify-center gap-1 py-2 rounded-lg text-xs font-medium transition-all ${postType === 'image' ? 'bg-white text-sky-600 shadow-sm' : 'text-slate-500 hover:bg-white/50'}`}
              >
                <ImageIcon size={16} />
                Imagens
              </button>
              <button 
                onClick={() => { setPostType('video-long'); setFiles([]); }}
                className={`flex flex-col items-center justify-center gap-1 py-2 rounded-lg text-xs font-medium transition-all ${postType === 'video-long' ? 'bg-white text-sky-600 shadow-sm' : 'text-slate-500 hover:bg-white/50'}`}
              >
                <Film size={16} />
                Vídeo
              </button>
              <button 
                onClick={() => { setPostType('ugc'); setFiles([]); }}
                className={`flex flex-col items-center justify-center gap-1 py-2 rounded-lg text-xs font-medium transition-all ${postType === 'ugc' ? 'bg-white text-sky-600 shadow-sm' : 'text-slate-500 hover:bg-white/50'}`}
              >
                <MonitorPlay size={16} />
                UGC
              </button>
              <button 
                onClick={() => { setPostType('video-from-image'); setFiles([]); }}
                className={`flex flex-col items-center justify-center gap-1 py-2 rounded-lg text-xs font-medium transition-all ${postType === 'video-from-image' ? 'bg-white text-sky-600 shadow-sm' : 'text-slate-500 hover:bg-white/50'}`}
              >
                <PlaySquare size={16} />
                Gerar vídeo
              </button>
              <button 
                onClick={() => { setPostType('restore'); setFiles([]); }}
                className={`flex flex-col items-center justify-center gap-1 py-2 rounded-lg text-xs font-medium transition-all col-span-2 ${postType === 'restore' ? 'bg-white text-sky-600 shadow-sm' : 'text-slate-500 hover:bg-white/50'}`}
              >
                <Wand2 size={16} />
                Restaurar
              </button>
            </div>

            {/* Campos de Input (Prompt) */}
            <div className="flex-1 overflow-y-auto custom-scrollbar pr-1">
                {postType === 'video-long' && (
                  <div className="animate-fade-in space-y-4">
                     <div className="bg-sky-50 border border-sky-100 rounded-lg p-3 text-xs text-sky-700 flex items-start gap-2">
                        <Info size={16} className="shrink-0 mt-0.5" />
                        <p>Preencha o roteiro e o autor para gerar seu vídeo institucional.</p>
                     </div>
                     <div>
                        <label className="block text-xs font-bold text-slate-800 mb-1.5">Texto / Roteiro *</label>
                        <textarea
                          value={prompt}
                          onChange={(e) => setPrompt(e.target.value)}
                          placeholder="Digite o texto do vídeo..."
                          className="w-full border border-slate-200 rounded-lg px-3 py-2 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-200 transition-all text-sm h-32"
                        />
                     </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       <div>
                          <label className="block text-xs font-bold text-slate-800 mb-1.5">Autor *</label>
                          <input
                            type="text"
                            value={author}
                            onChange={(e) => setAuthor(e.target.value)}
                            placeholder="Nome do autor"
                            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-200 transition-all text-sm"
                          />
                       </div>
                       <div>
                          <label className="block text-xs font-bold text-slate-800 mb-1.5">Link do YouTube (Opcional)</label>
                          <div className="relative">
                            <Youtube size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-red-500" />
                            <input
                              type="text"
                              value={youtubeUrl}
                              onChange={(e) => setYoutubeUrl(e.target.value)}
                              placeholder="https://youtube.com/..."
                              className="w-full border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-200 transition-all text-sm"
                            />
                          </div>
                       </div>
                     </div>
                  </div>
                )}

                {postType === 'ugc' && (
                  <div className="animate-fade-in space-y-2">
                    <label className="block text-xs font-bold text-slate-800">Prompt / Roteiro *</label>
                    <textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      placeholder="Ex: Um vídeo estilo selfie falando sobre..."
                      className="w-full border border-slate-200 rounded-lg px-3 py-2 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-200 transition-all text-sm h-48"
                    />
                  </div>
                )}

                {postType === 'video-from-image' && (
                  <div className="animate-fade-in bg-blue-50 border border-blue-100 rounded-lg p-3 text-xs text-blue-700 flex items-start gap-2 mb-2">
                    <Info size={16} className="shrink-0 mt-0.5" />
                    <p>Selecione uma imagem para transformá-la em vídeo.</p>
                  </div>
                )}

                {postType === 'restore' && (
                  <div className="animate-fade-in bg-purple-50 border border-purple-100 rounded-lg p-3 text-xs text-purple-700 flex items-start gap-2 mb-2">
                    <Info size={16} className="shrink-0 mt-0.5" />
                    <p>Restaure imagens antigas, remova ruídos e melhore a qualidade.</p>
                  </div>
                )}
                 
                 {postType === 'image' && (
                   <div className="bg-slate-50 rounded-lg p-4 text-center border border-dashed border-slate-200 text-slate-400 text-xs">
                      Envie imagens para alteração.
                   </div>
                 )}
            </div>
        </div>

        {/* Lado Direito: Upload Area (Escondido para Vídeo Longo) */}
        {postType !== 'video-long' && (
          <div className="md:col-span-7 flex flex-col h-full animate-fade-in">
               <div className="flex justify-between items-center mb-2">
                  <label className="block text-xs font-bold text-slate-800">
                      {postType === 'ugc' 
                        ? 'Imagem de Referência *' 
                        : (postType === 'video-from-image')
                          ? 'Arquivo de Referência (Apenas 1)' 
                          : 'Arquivos *'}
                  </label>
                  {files.length > 0 && (
                     <span className="text-xs text-slate-400">{files.length} arquivo(s)</span>
                  )}
               </div>
               
               <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileSelect} 
                  multiple={postType !== 'video-from-image'} 
                  className="hidden" 
                  accept="image/*"
               />

               <div 
                  className={`flex-1 border-2 border-dashed rounded-xl p-4 transition-all flex flex-col relative overflow-hidden ${files.length > 0 ? 'border-sky-400 bg-sky-50/20' : 'border-slate-200 hover:border-sky-300 hover:bg-sky-50/30'}`}
               >
                  {files.length > 0 ? (
                    <div className="h-full flex flex-col">
                       <div className="flex justify-end mb-2">
                          {(postType !== 'video-from-image') ? (
                            <button 
                              onClick={() => fileInputRef.current?.click()}
                              className="text-xs text-sky-600 bg-white px-3 py-1.5 rounded-lg border border-sky-100 hover:bg-sky-50 transition-colors font-medium flex items-center gap-1"
                            >
                              <Upload size={12} /> Adicionar
                            </button>
                          ) : (
                             <button 
                               onClick={() => fileInputRef.current?.click()}
                               className="text-xs text-sky-600 bg-white px-3 py-1.5 rounded-lg border border-sky-100 hover:bg-sky-50 transition-colors font-medium"
                             >
                               Trocar Arquivo
                             </button>
                          )}
                       </div>
                       
                       <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 overflow-y-auto custom-scrollbar p-1">
                          {previews.map((src, idx) => (
                            <div key={idx} className="relative group aspect-square rounded-lg overflow-hidden border border-slate-200 shadow-sm bg-white">
                               <img 
                                src={src} 
                                alt={`Preview ${idx}`} 
                                className="w-full h-full object-cover"
                               />
                               <button 
                                onClick={() => removeFile(idx)}
                                className="absolute top-1 right-1 bg-black/50 hover:bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-all"
                                title="Remover"
                               >
                                 <X size={12} />
                               </button>
                            </div>
                          ))}
                       </div>
                    </div>
                  ) : (
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="flex-1 flex flex-col items-center justify-center cursor-pointer min-h-[200px]"
                    >
                      <div className="bg-slate-100 p-3 rounded-full mb-3">
                        <Upload size={20} className="text-slate-400" />
                      </div>
                      <span className="text-sm font-medium text-slate-600">
                        Clique para Selecionar
                      </span>
                      <span className="text-xs text-slate-400 mt-1">
                        {(postType === 'video-from-image') ? 'Apenas 1 arquivo' : 'Múltiplos arquivos'}
                      </span>
                    </div>
                  )}
               </div>
          </div>
        )}
      </div>

      {/* Rodapé Informativo */}
      <div className="flex gap-2 text-[10px] text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-100 mt-4">
          <Info size={14} className="shrink-0 mt-0.5" />
          <p>Os arquivos serão enviados para processamento ({postType === 'video-long' ? 'storyboard' : postType}) e aparecerão na Galeria em breve.</p>
      </div>
    </ModalWrapper>
  );
};

// Add News Modal (Webhook Version)
export const AddNewsModal: React.FC<{ isOpen: boolean; onClose: () => void; user: User | null }> = ({ isOpen, onClose, user }) => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!url) return;
    if (!user) return;
    
    setLoading(true);
    try {
      const payload = {
        url: url,
        id_usuario: user.id,
        email: user.email,
        category: user.category || 'Geral'
      };

      console.log("Enviando notícia para webhook:", payload);

      await fetch('https://n8n-n8n.6wqa93.easypanel.host/webhook/criarNoticia', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        mode: 'cors'
      });

      alert("Solicitação enviada! A notícia aparecerá em breve.");
      onClose();
    } catch (error: any) {
      console.error("Error sending news to webhook:", error);
      if (isCorsOrNetworkError(error)) {
        // Fallback para erros de rede/CORS, assumindo que o webhook processou
        alert("Solicitação enviada! A notícia aparecerá em breve.");
        onClose();
      } else {
        alert("Erro ao enviar solicitação.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Adicionar Notícia"
      description="Cole o link da notícia para processamento automático"
      footer={
        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-50 text-sm">Cancelar</button>
          <button onClick={handleSend} disabled={loading || !url} className="bg-sky-500 text-white px-4 py-2 rounded-lg hover:bg-sky-600 disabled:opacity-50 flex items-center gap-2 text-sm">
             {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />} 
             {loading ? 'Enviando...' : 'Processar Notícia'}
          </button>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="bg-sky-50 border border-sky-100 rounded-lg p-3 text-xs text-sky-700 flex items-start gap-2">
           <Info size={16} className="shrink-0 mt-0.5" />
           <p>O link será enviado para nossa IA que irá resumir, categorizar e salvar a notícia automaticamente.</p>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">URL da Notícia</label>
          <div className="flex gap-2">
            <input 
              type="text" 
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://..."
              className="flex-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-100"
            />
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};

// Edit News Modal
export const EditNewsModal: React.FC<{ 
  isOpen: boolean; 
  newsItem: NewsItem | null; 
  onClose: () => void; 
  onUpdate: (item: NewsItem) => void;
  onDelete: (id: string) => void;
  user: User | null;
}> = ({ isOpen, newsItem, onClose, onUpdate, onDelete, user }) => {
  const [formData, setFormData] = useState<Partial<NewsItem>>({});
  const [saving, setSaving] = useState(false);
  const [creatingContent, setCreatingContent] = useState(false);

  useEffect(() => {
    if (newsItem) {
      setFormData(newsItem);
    }
  }, [newsItem]);

  const handleSave = async () => {
    if (!newsItem || !formData) return;
    setSaving(true);
    try {
      await updateNews(newsItem.id, formData);
      onUpdate({ ...newsItem, ...formData } as NewsItem);
      onClose();
    } catch (error) {
      console.error("Error updating news:", error);
      alert("Erro ao atualizar notícia.");
    } finally {
      setSaving(false);
    }
  };

  const handleCreateContent = async () => {
    if (!newsItem || !user) return;
    
    // 1. Credit Check
    if (user.imageCredits <= 0) {
      alert("Saldo insuficiente de créditos de IMAGEM.");
      return;
    }

    setCreatingContent(true);
    try {
      // 2. Prepare Payload
      const payload = {
        titulo: formData.title || newsItem.title,
        resumo: formData.summary || newsItem.summary, // Mapped to 'resumo' as requested
        usuario: user.name, // Mapped to 'usuario' as requested
        email: user.email,
        id_noticia: newsItem.id,
        id_usuario: user.id // Keeping id_usuario for backend compatibility/safety
      };

      // 3. Send Webhook
      await fetch('https://n8n-n8n.6wqa93.easypanel.host/webhook/criarnoticias_imagem', {
         method: 'POST',
         headers: { 'Content-Type': 'application/json' },
         body: JSON.stringify(payload),
         mode: 'cors'
      });

      // 4. Deduct Credit
      await deductCredits(user.id, 'image', 1, 'Conteúdo Notícia: ' + (formData.title || newsItem.title));
      user.imageCredits -= 1; // Visual update

      alert('Solicitação enviada! O conteúdo será gerado em breve.');
    } catch(e: any) {
      console.error("Erro ao criar conteúdo da notícia:", e);
      // Fallback para erros de rede/CORS
      if (isCorsOrNetworkError(e)) {
         // Tenta debitar mesmo com erro de CORS pois o webhook geralmente funciona
         try {
            await deductCredits(user.id, 'image', 1, 'Conteúdo Notícia: ' + (formData.title || newsItem.title));
            user.imageCredits -= 1;
         } catch (err) {}
         alert('Solicitação enviada!');
      } else {
         alert('Erro ao enviar solicitação.');
      }
    } finally {
      setCreatingContent(false);
    }
  };

  if (!newsItem) return null;

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Editar Notícia"
      footer={
        <div className="flex justify-between w-full">
           <button onClick={() => { onDelete(newsItem.id); onClose(); }} className="text-red-500 hover:text-red-600 flex items-center gap-1 text-sm font-medium">
             <Trash2 size={16} /> Excluir
           </button>
           <div className="flex gap-2">
             <button 
               onClick={handleCreateContent} 
               disabled={creatingContent} 
               className="bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded-lg disabled:opacity-50 flex items-center gap-2 text-sm shadow-sm shadow-purple-100"
             >
                {creatingContent ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
                Criar Conteúdo
             </button>
             <button onClick={onClose} className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-50 text-sm">Cancelar</button>
             <button onClick={handleSave} disabled={saving} className="bg-sky-500 text-white px-4 py-2 rounded-lg hover:bg-sky-600 disabled:opacity-50 flex items-center gap-2 text-sm">
               {saving && <Loader2 size={16} className="animate-spin" />} Salvar
             </button>
           </div>
        </div>
      }
    >
      <div className="space-y-4">
         <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Título</label>
            <input 
              type="text" 
              value={formData.title || ''}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-100"
            />
         </div>
         <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Resumo / Conteúdo</label>
            <textarea 
              value={formData.summary || ''}
              onChange={(e) => setFormData({...formData, summary: e.target.value})}
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-100 h-32"
            />
         </div>
         <div className="grid grid-cols-2 gap-4">
             <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Categoria</label>
                <input 
                  type="text" 
                  value={formData.category || ''}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-100"
                />
             </div>
             <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Status</label>
                <select 
                   value={formData.status || 'draft'}
                   onChange={(e) => setFormData({...formData, status: e.target.value as any})}
                   className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-100"
                >
                   <option value="draft">Rascunho</option>
                   <option value="published">Publicada</option>
                </select>
             </div>
         </div>
         <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Link Original</label>
            <div className="flex gap-2 items-center">
              <input 
                type="text" 
                value={formData.url || ''}
                onChange={(e) => setFormData({...formData, url: e.target.value})}
                className="flex-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-100 text-slate-500"
              />
              {formData.url && (
                <a href={formData.url} target="_blank" rel="noreferrer" className="text-sky-500 hover:text-sky-600">
                  <ExternalLink size={18} />
                </a>
              )}
            </div>
         </div>
      </div>
    </ModalWrapper>
  );
};

// Create Avatar Video Modal
export const CreateAvatarVideoModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
}> = ({ isOpen, onClose, user }) => {
  const [script, setScript] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [selectedStyle, setSelectedStyle] = useState<string | null>(null);
  
  // Recupera Cameo do perfil do usuário
  const cameoUrl = user?.preferences?.socialMedia?.cameoSora2 || '';

  const handleCreate = async () => {
    if (!user || !script) return;
    
    // VERIFICAÇÃO DE SALDO (Adicionada)
    if (user.videoCredits < 1) {
       alert("Saldo insuficiente. Você precisa de pelo menos 1 crédito de VÍDEO.");
       return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('id_usuario', user.id);
      formData.append('email', user.email);
      
      // Busca o objeto de estilo selecionado
      const styleObj = selectedStyle ? avatarStyles.find(s => s.id === selectedStyle) : null;
      
      // Envia explicitamente os dados do estilo para o webhook
      if (styleObj) {
         formData.append('style_name', styleObj.name);
         formData.append('style_prompt', styleObj.prompt);
      }
      
      // Combina o prompt do estilo visual com o script do usuário, se houver estilo selecionado
      const finalPrompt = styleObj ? `[Estilo Visual: ${styleObj.prompt}] \n\nTexto Falado: ${script}` : script;
      
      formData.append('prompt', finalPrompt);
      formData.append('type', 'avatar');
      // Adiciona o Cameo ao payload
      formData.append('cameo', cameoUrl);

      // Use generic avatar webhook or similar
      // Removido mode: 'no-cors' para garantir envio correto
      await fetch('https://n8n-n8n.6wqa93.easypanel.host/webhook/criarAvatar', {
         method: 'POST',
         body: formData
      });
      
      // Debitar crédito (Assuming video credit)
      await deductCredits(user.id, 'video', 1, 'Criação de Avatar');
      user.videoCredits -= 1;

      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        setScript('');
        setSelectedStyle(null);
        onClose();
      }, 2000);
    } catch (error) {
      console.error("Error creating avatar video:", error);
      alert("Erro ao enviar solicitação.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Criar Vídeo Avatar"
      description="Gere um vídeo falado usando um avatar"
      maxWidth="max-w-2xl"
      footer={
         <div className="flex justify-end gap-2">
            <button onClick={onClose} className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-50 text-sm">Cancelar</button>
            <button onClick={handleCreate} disabled={loading || success || !script} className="bg-sky-500 text-white px-4 py-2 rounded-lg hover:bg-sky-600 disabled:opacity-50 flex items-center gap-2 text-sm">
               {loading ? <Loader2 size={16} className="animate-spin" /> : success ? <CheckCircle2 size={16} /> : <Film size={16} />} 
               {success ? 'Enviado!' : 'Gerar Vídeo'}
            </button>
         </div>
      }
    >
       <div className="space-y-6">
          <div>
             <label className="block text-xs font-bold text-slate-700 mb-1">Roteiro / Texto *</label>
             <textarea 
               value={script}
               onChange={(e) => setScript(e.target.value)}
               placeholder="Digite o texto exato que o avatar deve falar..."
               className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-100 h-28 resize-none"
             />
          </div>

          <div>
             <label className="block text-xs font-bold text-slate-700 mb-2">Escolha um Estilo / Cenário (Opcional)</label>
             <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
               {avatarStyles.map((style) => (
                 <div 
                   key={style.id}
                   onClick={() => setSelectedStyle(selectedStyle === style.id ? null : style.id)}
                   className={`relative cursor-pointer rounded-lg overflow-hidden border-2 transition-all ${selectedStyle === style.id ? 'border-sky-500 ring-2 ring-sky-200 ring-offset-1' : 'border-transparent hover:border-slate-300'}`}
                 >
                    <img src={style.img} alt={style.name} className="w-full h-20 object-cover" />
                    <div className={`absolute inset-0 bg-black/40 flex items-end p-2 ${selectedStyle === style.id ? 'opacity-100' : 'opacity-0 hover:opacity-100'} transition-opacity`}>
                       <span className="text-[10px] text-white font-bold leading-tight">{style.name}</span>
                    </div>
                    {selectedStyle === style.id && (
                       <div className="absolute top-1 right-1 bg-sky-500 rounded-full p-0.5">
                          <CheckCircle2 size={12} className="text-white" />
                       </div>
                    )}
                 </div>
               ))}
             </div>
             {selectedStyle && (
                <div className="mt-2 text-xs text-sky-600 bg-sky-50 p-2 rounded border border-sky-100">
                   <strong>Estilo Selecionado:</strong> {avatarStyles.find(s => s.id === selectedStyle)?.prompt}
                </div>
             )}
          </div>

          <div>
             <label className="block text-xs font-bold text-slate-700 mb-1">Cameo ID / URL (Configurado no Perfil)</label>
             {cameoUrl ? (
                <div className="w-full bg-slate-100 border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-600 truncate">
                   {cameoUrl}
                </div>
             ) : (
                <div className="text-xs text-amber-600 bg-amber-50 p-2 rounded border border-amber-200 flex items-center justify-between">
                   <span>Você não configurou seu Cameo Sora2 no perfil.</span>
                   <Link to="/profile" className="underline font-bold ml-1 text-amber-700">Configurar</Link>
                </div>
             )}
          </div>
       </div>
    </ModalWrapper>
  );
};

// Create Video From Image Modal
export const CreateVideoFromImageModal: React.FC<{
  isOpen: boolean;
  imageUrl: string;
  user: User | null;
  onClose: () => void;
  imageDescription?: string;
}> = ({ isOpen, imageUrl, user, onClose, imageDescription }) => {
  const [prompt, setPrompt] = useState(imageDescription || '');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
     if (isOpen) setPrompt(imageDescription || '');
  }, [isOpen, imageDescription]);

  const handleCreate = async () => {
    if (!user || !imageUrl) return;
    
    if (user.videoCredits <= 0) {
       alert("Créditos de vídeo insuficientes.");
       return;
    }

    setLoading(true);
    try {
      // 1. Fetch the image to create a File object
      const res = await fetch(imageUrl);
      const blob = await res.blob();
      const file = new File([blob], "source_image.png", { type: blob.type });

      // 2. Send to Webhook
      const formData = new FormData();
      formData.append('files', file);
      formData.append('id_usuario', user.id);
      formData.append('email', user.email);
      formData.append('type', 'video'); // Reuse 'video' logic for video-from-image
      if (prompt) formData.append('prompt', prompt);

      const webhookUrl = 'https://n8n-n8n.6wqa93.easypanel.host/webhook/criarImagempvideo';

      console.log('--- DEBUG: Gerar Vídeo da Imagem ---');
      console.log('Webhook URL:', webhookUrl);
      console.log('Payload FormData:');
      console.log('files:', file.name);
      console.log('id_usuario:', user.id);
      console.log('email:', user.email);
      console.log('type:', 'video');
      console.log('prompt:', prompt);
      console.log('------------------------------------');

      // Removido mode: 'no-cors' para garantir envio correto
      await fetch(webhookUrl, {
         method: 'POST',
         body: formData
      });

      // 3. Deduct Credits
      await deductCredits(user.id, 'video', 1, 'Vídeo a partir de Imagem');
      user.videoCredits -= 1;

      setSuccess(true);
      setTimeout(() => {
         setSuccess(false);
         onClose();
      }, 2000);

    } catch (error) {
      console.error("Error creating video from image:", error);
      alert("Erro ao processar solicitação.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ModalWrapper
       isOpen={isOpen}
       onClose={onClose}
       title="Gerar Vídeo da Imagem"
       footer={
          <div className="flex justify-end gap-2">
             <button onClick={onClose} className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-50 text-sm">Cancelar</button>
             <button onClick={handleCreate} disabled={loading || success} className="bg-sky-500 text-white px-4 py-2 rounded-lg hover:bg-sky-600 disabled:opacity-50 flex items-center gap-2 text-sm">
                {loading ? <Loader2 size={16} className="animate-spin" /> : success ? <CheckCircle2 size={16} /> : <Video size={16} />}
                {success ? 'Enviado!' : 'Criar Vídeo (1 Crédito)'}
             </button>
          </div>
       }
    >
       <div className="space-y-4">
          <div className="aspect-video bg-slate-100 rounded-lg overflow-hidden border border-slate-200">
             <img src={imageUrl} alt="Source" className="w-full h-full object-contain" />
          </div>
          <div>
             <label className="block text-xs font-bold text-slate-700 mb-1">Descrição do Movimento / Prompt (Opcional)</label>
             <textarea 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Descreva como a imagem deve se mover..."
                className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-100 h-24"
             />
          </div>
       </div>
    </ModalWrapper>
  );
};
