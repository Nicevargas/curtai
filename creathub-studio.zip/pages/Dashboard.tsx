
import React, { useState } from 'react';
import { Clock, CheckCircle, Calendar as CalendarIcon, TrendingUp, Image as ImageIcon, FileText, Sparkles, Plus, Layers, UserCircle, ChevronRight } from 'lucide-react';
import { NewsFeed } from '../components/NewsFeed';
import { RecentGallery } from '../components/RecentGallery';
import { User, PlanType } from '../types';
import { CreateAvatarVideoModal } from '../components/Modals';

interface DashboardProps {
  user: User | null;
  onCreatePost: (type: 'image' | 'ugc' | 'video-long') => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onCreatePost }) => {
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  
  const currentDate = new Date().toLocaleDateString('pt-BR', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  return (
    <div className="space-y-6 animate-fade-in pb-8">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">
            Olá, {user?.name ? user.name.split(' ')[0] : 'Visitante'} 👋
          </h1>
          <p className="text-slate-500 mt-1 capitalize">{currentDate}</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-full px-4 py-1.5 text-sm text-slate-600 font-medium shadow-sm flex items-center gap-2">
           <Sparkles size={14} className="text-sky-500" />
           <span className="text-slate-500">Plano:</span>
           <span className={`px-2 py-0.5 rounded-md text-xs font-bold uppercase border ${
               user?.plan === 'Business' 
                 ? 'bg-amber-50 text-amber-600 border-amber-200' 
                 : 'bg-slate-100 text-slate-500 border-slate-200'
             }`}>
               {user?.plan || 'Teste'}
           </span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Posts Agendados" value="3" icon={Clock} color="text-sky-600" bg="bg-sky-100" />
        <StatCard title="Publicados" value="12" icon={CheckCircle} color="text-sky-600" bg="bg-sky-100" />
        <StatCard title="Esta Semana" value="5" icon={CalendarIcon} color="text-sky-600" bg="bg-sky-100" />
        <StatCard title="Crescimento" value="+12%" icon={TrendingUp} color="text-sky-600" bg="bg-sky-100" isPercentage />
      </div>

      {/* Action Buttons Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Card: Criar Notícias */}
          <button 
            onClick={() => window.location.hash = '#/calendar'}
            className="group relative overflow-hidden bg-gradient-to-r from-sky-400 to-blue-500 rounded-2xl p-5 text-left shadow-md hover:shadow-lg transition-all transform hover:-translate-y-1 flex items-center justify-between h-[100px]"
          >
              <div className="absolute -right-6 -bottom-6 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110">
                <FileText size={100} className="text-white" />
              </div>
              <div className="relative z-10 flex items-center gap-4">
                <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center backdrop-blur-sm text-white shrink-0">
                    <Plus size={24} />
                </div>
                <div>
                    <h3 className="text-white font-bold text-lg">Criar Notícias</h3>
                    <p className="text-sky-50 text-xs mt-0.5 opacity-90">Nova notícia via link</p>
                </div>
              </div>
              <div className="relative z-10 bg-white/10 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity">
                 <ChevronRight size={20} />
              </div>
          </button>

          {/* Card: Criar Conteúdo */}
          <button 
            onClick={() => onCreatePost('image')}
            className="group relative overflow-hidden bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl p-5 text-left shadow-md hover:shadow-lg transition-all transform hover:-translate-y-1 flex items-center justify-between h-[100px]"
          >
              <div className="absolute -right-6 -bottom-6 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110">
                <ImageIcon size={100} className="text-white" />
              </div>
              <div className="relative z-10 flex items-center gap-4">
                <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center backdrop-blur-sm text-white shrink-0">
                    <Sparkles size={24} />
                </div>
                <div>
                    <h3 className="text-white font-bold text-lg">Criar Conteúdo</h3>
                    <p className="text-blue-50 text-xs mt-0.5 opacity-90">Gerar imagem ou vídeo</p>
                </div>
              </div>
              <div className="relative z-10 bg-white/10 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity">
                 <ChevronRight size={20} />
              </div>
          </button>
      </div>

      {/* Premium Options - Only visible for Premium plan or Test User */}
      {(user?.plan === PlanType.PREMIUM || user?.plan === PlanType.BUSINESS || user?.email === 'eunicelvargas@gmail.com') && (
        <div className="grid grid-cols-2 gap-4">
           <button 
             onClick={() => alert('Funcionalidade Carrossel em breve!')}
             className="bg-white border border-sky-100 hover:border-sky-300 text-sky-600 p-4 rounded-xl shadow-sm transition-all flex items-center justify-center gap-3 group hover:shadow-md"
           >
             <div className="bg-sky-50 p-2 rounded-full group-hover:scale-110 transition-transform">
                <Layers size={20} />
             </div>
             <span className="font-bold text-sm">Carrossel</span>
           </button>
           <button 
             onClick={() => setIsAvatarModalOpen(true)}
             className="bg-white border border-sky-100 hover:border-sky-300 text-sky-600 p-4 rounded-xl shadow-sm transition-all flex items-center justify-center gap-3 group hover:shadow-md"
           >
             <div className="bg-sky-50 p-2 rounded-full group-hover:scale-110 transition-transform">
                <UserCircle size={20} />
             </div>
             <span className="font-bold text-sm">Avatar</span>
           </button>
        </div>
      )}

      {/* News Feed (Full Width) - Reduced Height */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden h-[240px]">
          {user ? (
              <NewsFeed user={user} />
          ) : (
              <div className="p-8 animate-pulse flex flex-col gap-4">
                <div className="h-8 bg-slate-100 rounded w-1/3"></div>
                <div className="h-32 bg-slate-100 rounded w-full"></div>
              </div>
          )}
      </div>

      {/* Recent Gallery Section (Bottom) */}
      {user && <RecentGallery user={user} />}

      {/* Modal for Avatar Video */}
      <CreateAvatarVideoModal 
        isOpen={isAvatarModalOpen}
        onClose={() => setIsAvatarModalOpen(false)}
        user={user}
      />
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ElementType;
  color: string;
  bg: string;
  isPercentage?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon, color, bg }) => (
  <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4 hover:border-sky-100 transition-colors">
    <div className={`p-3 rounded-xl ${bg} ${color}`}>
      <Icon size={20} />
    </div>
    <div>
      <p className="text-slate-500 text-xs font-medium uppercase tracking-wide">{title}</p>
      <div className="text-2xl font-bold text-slate-800 mt-0.5">
        {value}
      </div>
    </div>
  </div>
);

export default Dashboard;
